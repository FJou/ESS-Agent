#!/bin/bash
# process.sh - Apache webhosting automation demo script


echo $KEH_HOSTNAME,$KEH_ESS_PORT