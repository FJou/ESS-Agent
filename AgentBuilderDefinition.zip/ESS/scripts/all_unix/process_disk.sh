#!/bin/bash
# process.sh - Apache webhosting automation demo script

curl -k -X GET --header 'Accept: application/json' -u admin:admin001 https://$KEH_HOSTNAME:443/scalemgmt/v2/perfmon/data?query="metrics%20-i%20-a%20gpfs_disk_disksize,gpfs_disk_free_fullkb%20last%202%20bucket_size%2086400" > a

cat a | sed -n '/\[.*\]/p' > b
grep keys b |  awk -F'[][]' '{print $2}' | awk -F'"' '{print $2}' | awk -F'|' '{print $3,$4,$5,$6}' > c.txt
grep values b | head -1 | awk -F'[][]' '{print $2}' > d.txt

file1=./c.txt
file2=./d.txt

lc=`wc -l < $file1`
#lc=`expr $lc - 1`
#echo $lc

# set the Internal Field Separator to , 
IFS=', '
read -a array < $file2
#echo ${array[@]}

cat /dev/null > d1.txt

for (( i=0; i<$lc; i++))
do
	IFS= read -r message
	echo $message ${array[$i]} >> d1.txt
done < "$file1"

cat d1.txt | awk -F' ' '{print $1,$2,$3}' | sort | uniq > d2.txt

lc=`wc -l < d2.txt`

for (( i=0; i<$lc; i++ ))
do 
	IFS= read -r message
	message1=$(echo "$message ")
	grep "$message1" d1.txt > d3.txt
	lc2=`wc -l < d3.txt`
	for ((j=0; j<$lc2; j++))
	do 
		IFS= read -r message_line
		if (( $j==0 ))
		then
		   # num_fields=$(echo $message_line | awk -F' ' '{print NF}')
                   last_field=$(echo $message_line | awk -F' ' '{print $5}')
                   # echo $last_field
                   new_line=$(echo $message1 $last_field)
		else
		   new_comp=$(echo $message_line | awk -F' ' '{print $5}')
		   new_line=$(echo $new_line $new_comp)
		fi
	done < d3.txt
	echo $new_line
done < d2.txt
